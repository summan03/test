﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {

            int i, n;
            int fac=1;
            Console.WriteLine("Enter Number : ");
            Console.ReadLine("%d", n);
            for (i = 0; i < 10; i++)
            {
                fac = fac * i;
            }
            Console.WriteLine("Factorial = %d",fac);
        }
    }
}
