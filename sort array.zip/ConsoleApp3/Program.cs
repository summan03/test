﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = new int[n];

            int c, i, j, n, swap;
            for (i = 0; i < 10; i++)
            {
                Console.WriteLine("Enter size : ");
                Console.ReadLine("%d", n);
                Console.WriteLine("Enter Number : ");
                Console.ReadLine("%d",num[i]);
            }
            for(c=0;c<(n-1);c++)
            {
                for (j = 0; j < (n-c-1); j++)
                {
                    if(num[d] > num[d+1])
                    {
                        swap = num[d];
                        num[d] = num[d + 1];
                        num[d + 1] = swap;
                    }
                }
            
                
            }
            Console.WriteLine("Hello World!");
        }
    }
}
