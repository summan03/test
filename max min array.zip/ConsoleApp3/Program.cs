﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = new int[10];
            int i, j, max, min;
            for (i = 0; i < 10; i++)
            {
                Console.WriteLine("Enter Number : ");
                Console.ReadLine("%d",num[i]);
            }
            min = num[0];
            for (j = 0; j < 10; j++)
            {
                if (min > num[j]) min = num[j];
                else if (max < num[j]) max = num[j];
                else { }
            }
            Console.WriteLine("Min %d max %d",min,max);
            return 0;
        }
    }
}
